#' Multiply two values
#'
#' @param a A number
#' @param b A number
#' @return The value of a times b
#' @export
#' @examples
#' print("Hello, World!")
#' mply (2,4)
mply <- function(a, b){
  a * b
}
