## ---- include = FALSE----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup---------------------------------------------------------------
library(FirstRPackage)
library(tidyverse)


## ----load-data-----------------------------------------------------------
data("StandardizationAssayData")

## ----summary-data--------------------------------------------------------
summary(StandardizationAssayData)

## ----call-help-----------------------------------------------------------
?StandardizationAssayData

## ----Peak-MT-by-Relative-PA----------------------------------------------
ggplot(data = StandardizationAssayData, aes(x = `Peak MT`, y = `Relative PA`)) + geom_point()

## ----Peak-MT-by-Relative-PA Differentiation------------------------------
ggplot(data = StandardizationAssayData, aes(x = `Peak MT`, y = `Relative PA`, color = factor(`Samplle Vial`))) + geom_point()

## ----mean-function-------------------------------------------------------
?mean1

## ----mean-calculation----------------------------------------------------
mean(StandardizationAssayData$`Peak MT`)

